// script.js

function openModal(url, modalId) {
    fetch(url)
        .then(response => response.text())
        .then(data => {
            document.getElementById(modalId).innerHTML = data;
            document.getElementById(modalId).style.display = 'block';
        })
        .catch(error => console.error('Error fetching content:', error));
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}
